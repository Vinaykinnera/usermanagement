package com.vinay.model;



import java.sql.Blob;



import javax.persistence.Column;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Lob;

import javax.persistence.Table;



@Entity



@Table(name="staffimages")

public class StaffImage{

   @Id

   @Column

   int id;
   
   @Column

   String staffname;
   
   @Column

   String description;
   
   
   @Column
   String qualification;


   @Column

   @Lob

   private Blob image;

   public int getId() {

       return id;

   }

   public void setId(int id) {

       this.id = id;

   }


   public Blob getImage() {

       return image;

   }

   public void setImage(Blob image) {

       this.image = image;

   }

   public StaffImage(int id, Blob image) {

       super();

       this.id = id;

       

       this.image = image;

   }

   public StaffImage(Blob image) {

       super();


       this.image = image;

   }

   public StaffImage() {

       super();

   }

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

 

public String getStaffname() {
	return staffname;
}

public void setStaffname(String staffname) {
	this.staffname = staffname;
}

public String getQualification() {
	return qualification;
}

public void setQualification(String qualification) {
	this.qualification = qualification;
}


   

   

   

   

}
