package com.vinay.model;



import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="product")
public class Product {
	@Id
	@Column
	int id;
	@Column
    String productname;
	@Column
	String productprice;
	@Column
	String season;
	  @Transient
	    private boolean addedToCart;
	 
  
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getProductprice() {
		return productprice;
	}
	public void setProductprice(String productprice) {
		this.productprice = productprice;
	}
	public String getSeason() {
		return season;
	}
	public void setSeason(String season) {
		this.season = season;
	}
	 public boolean isAddedToCart() {
	        return addedToCart;
	    }

	    public void setAddedToCart(boolean addedToCart) {
	        this.addedToCart = addedToCart;
	    }
	 
}
