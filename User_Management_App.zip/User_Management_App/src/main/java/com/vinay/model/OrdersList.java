package com.vinay.model;

import javax.persistence.Column;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="orderslist")
public class OrdersList {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	long id;
	@Column
	long paymentid;
	@Column
    String productname;
	@Column
	String productprice;
	@Column
	int quantity;
	
	public OrdersList(long paymentid, String productname, String productprice, int quantity) {
		super();
		this.paymentid = paymentid;
		this.productname = productname;
		this.productprice = productprice;
		this.quantity = quantity;
	}


	public OrdersList() {
		super();
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public OrdersList(long long1, String productname2, String productprice2) {
		// TODO Auto-generated constructor stub
		this.paymentid=long1;
		this.productname=productname2;
		this.productprice=productprice2;
	}
 

	public long getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public long getPaymentid() {
		return paymentid;
	}

	public void setPaymentid(long paymentid) {
		this.paymentid = paymentid;
	}

	 

	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getProductprice() {
		return productprice;
	}
	public void setProductprice(String productprice) {
		this.productprice = productprice;
	}
 
	public void setId(long id) {
		this.id = id;
	}
	 
	
 
	
}
