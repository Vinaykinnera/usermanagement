package com.vinay.model;



import java.sql.Blob;



import javax.persistence.Column;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Lob;

import javax.persistence.Table;



@Entity



@Table(name="userimages")

public class UserImage{

   @Id

   @Column

   int id;
   
   @Column
   String username;
   
   @Column
   String qualification;
   
   @Column
   String address;
   
   @Column
   String contact;
   
   @Column
   String role;


   @Column

   @Lob

   private Blob image;

   public int getId() {

       return id;

   }

   public void setId(int id) {

       this.id = id;

   }


   public Blob getImage() {

       return image;

   }

   public void setImage(Blob image) {

       this.image = image;

   }

   public UserImage(int id, Blob image) {

       super();

       this.id = id;

       

       this.image = image;

   }

   public UserImage(Blob image) {

       super();


       this.image = image;

   }

   public UserImage() {

       super();

   }
   
   

public String getRole() {
	return role;
}

public void setRole(String role) {
	this.role = role;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getQualification() {
	return qualification;
}

public void setQualification(String qualification) {
	this.qualification = qualification;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getContact() {
	return contact;
}

public void setContact(String contact) {
	this.contact = contact;
}

   

   

   

   

}
