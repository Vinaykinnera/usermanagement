package com.vinay.model;



import java.sql.Blob;



import javax.persistence.Column;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Lob;

import javax.persistence.Table;



@Entity



@Table(name="fruitimages")

public class FruitImage{

   @Id

   @Column

   int id;
   
   @Column

   String productname;
   @Column

   String productprice;
   @Column

   String description;
   
   


   @Column

   @Lob

   private Blob image;

   public int getId() {

       return id;

   }

   public void setId(int id) {

       this.id = id;

   }


   public Blob getImage() {

       return image;

   }

   public void setImage(Blob image) {

       this.image = image;

   }

   public FruitImage(int id, Blob image) {

       super();

       this.id = id;

       

       this.image = image;

   }

   public FruitImage(Blob image) {

       super();


       this.image = image;

   }

   public FruitImage() {

       super();

   }

public String getProductname() {
	return productname;
}

public void setProductname(String productname) {
	this.productname = productname;
}

public String getProductprice() {
	return productprice;
}

public void setProductprice(String productprice) {
	this.productprice = productprice;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

 

   

   

   

   

}
