package com.vinay.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.vinay.model.Orders;
import com.vinay.model.OrdersList;
import com.vinay.model.Product;


public interface OrdersListRepository extends CrudRepository<OrdersList, Long>
{

	List<OrdersList> findByPaymentid(long paymentId);

	 
 
	
}
