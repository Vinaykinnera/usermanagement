package com.vinay.repository;


import org.springframework.data.repository.CrudRepository;

import com.vinay.model.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>
{

	 
	
}
