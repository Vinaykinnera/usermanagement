package com.vinay.repository;

import org.springframework.data.repository.CrudRepository;

import com.vinay.model.Staff;

public interface StaffRepository extends CrudRepository<Staff, Integer>
{
	
}
