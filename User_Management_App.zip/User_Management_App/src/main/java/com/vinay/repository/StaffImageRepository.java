package com.vinay.repository;

import org.springframework.data.repository.CrudRepository;


import com.vinay.model.StaffImage;


public interface StaffImageRepository extends CrudRepository<StaffImage, Integer>
{
	
}
