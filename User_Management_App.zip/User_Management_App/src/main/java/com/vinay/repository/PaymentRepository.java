package com.vinay.repository;
 

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
 
import com.vinay.model.PaymentDetails;


public interface PaymentRepository extends CrudRepository<PaymentDetails, Integer>
{
 
	 boolean existsByUtr(String utr);

	List<PaymentDetails> findByUserid(int id);

	Optional<PaymentDetails> getById(long id);
 

	 
	
}
