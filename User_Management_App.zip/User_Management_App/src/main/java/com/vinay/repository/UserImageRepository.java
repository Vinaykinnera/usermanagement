package com.vinay.repository;

import org.springframework.data.repository.CrudRepository;

import com.vinay.model.FruitImage;
import com.vinay.model.UserImage;


public interface UserImageRepository extends CrudRepository<UserImage, Integer>
{
	
}
