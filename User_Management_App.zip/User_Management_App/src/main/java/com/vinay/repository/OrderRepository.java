package com.vinay.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.vinay.model.Orders;


public interface OrderRepository extends CrudRepository<Orders, Integer>
{

	Optional<Orders> findByProductidAndUserid(int productid, int userid);

	List<Orders> findByUserid(int userid);
	 
	
}
