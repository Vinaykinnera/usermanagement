package com.vinay.repository;

import org.springframework.data.repository.CrudRepository;

import com.vinay.model.FruitImage;


public interface FruitImageRepository extends CrudRepository<FruitImage, Integer>
{
	
}
