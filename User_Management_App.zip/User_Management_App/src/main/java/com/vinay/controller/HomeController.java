package com.vinay.controller;


import java.io.IOException;


import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.sql.Blob;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.vinay.model.Orders;
import com.vinay.model.PaymentDetails;
import com.vinay.model.*;
import com.vinay.model.UserDtls;
import com.vinay.repository.PaymentRepository;
import com.vinay.repository.UserRepository;
import com.vinay.service.OrderService;
import com.vinay.service.OrdersListService;
import com.vinay.service.PaymentService;
import com.vinay.service.ProductService;
import com.vinay.service.StaffImageService;
import com.vinay.service.FruitImageService;
import com.vinay.service.StaffService;
import com.vinay.service.UserImageService;
import com.vinay.service.UserService;

@Controller
public class HomeController {

    @Autowired
    UserService userService;
    
    @Autowired
    ProductService productService;
    
    @Autowired
    StaffService staffService;
    
    @Autowired
    UserRepository userRepo;
    
    @Autowired
    PaymentRepository paymentRepository;
    
    @Autowired
    OrderService orderService;
    
    @Autowired
    PaymentService paymentService;
    
    @Autowired
    OrdersListService ordersListService;
    
    @Autowired
    FruitImageService fruitImageService;
    
    @Autowired
    StaffImageService staffImageService;
    
    @Autowired
    UserImageService userImageService;
   
    
    @Autowired
	private BCryptPasswordEncoder passwordEncoder;
    
    @PostMapping("/createUser")
    public String createUser(@ModelAttribute UserDtls user, HttpSession session, @RequestParam("image") MultipartFile file) throws IOException, SerialException, SQLException {
        boolean emailExists = userService.checkEmail(user.getEmail());
        if (emailExists) {
            session.setAttribute("msg", "Email Id already exists");
        } else {
            UserDtls userDtls = userService.createUser(user);
            if (userDtls != null) {
            	 byte[] bytes = file.getBytes();
     	        Blob blob = new javax.sql.rowset.serial.SerialBlob(bytes);
     	        UserImage user1 = new UserImage();
     	        user1.setImage(blob);
     	        user1.setAddress(user.getAddress());
     	        user1.setQualification(user.getQualification());
     	        user1.setUsername(user.getFullName());
     	        user1.setContact(user.getEmail());
     	        user1.setRole(user.getRole());
     	        userImageService.saveOrUpdate(user1);
                session.setAttribute("msg", "Registered successfully");
            } else {
                session.setAttribute("msg", "Something went wrong on the server");
            }
        }
        return "redirect:/register";
    }
    
    @GetMapping("/")
    public String index() {
        return "login";
    }

    @GetMapping("/signin")
    public String login() {
        return "login";
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }
    
    
    @GetMapping("/newproduct")
    public String newproduct() {
        return "newproduct";
    }
    
    @GetMapping("/newstaff")
    public String newstaff() {
        return "newstaff";
    }
    
    @GetMapping("/home")
    public String home() {
        return "home";
    }
    @GetMapping("/index")
    public String index1() {
        return "index";
    }
    
    @GetMapping("/orderdetails")
    public String orderdetails() {
        return "orderdetails";
    }
    
    @GetMapping("/payment")
    public String payment(@RequestParam("totalBill") String totalBill,
                          @RequestParam("quantities") String quantities,
                          Model model) {
        // Pass the totalBill and quantities to the payment page
        model.addAttribute("totalBill", totalBill);
        model.addAttribute("quantities", quantities);

        return "payment";
    }
    
    @PostMapping("/updatingstatus")
    public ModelAndView updateStatus(@RequestParam("status") String status,@RequestParam("paymentId")long id,HttpSession session) {
    	long Id= id;
    	System.out.print(Id);
        Optional<PaymentDetails> paymentDetails= paymentRepository.getById(Id);
       PaymentDetails newpaymentDetails=paymentDetails.get();
       newpaymentDetails.setStatus(status);
       paymentService.save(newpaymentDetails);
       
        ModelAndView modelAndView = listDept6(session);
        modelAndView.addObject("updateSuccess", true);
        return modelAndView;
    }


    
    @RequestMapping("/vijay")
    public ModelAndView listDept2() {
        List<Staff> staffList = staffService.getAllStaff();
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("staffdetails");
        modelAndView.addObject("staff", staffList);
        return modelAndView;
    }
    
    @RequestMapping("/veda")
    public ModelAndView listDept5(@RequestParam("id") long paymentId,@RequestParam("totalBill")double totalBill) {
       List<OrdersList> ordersList = ordersListService.getById(paymentId);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("orderdetails");
        modelAndView.addObject("orderdetails", ordersList);
        modelAndView.addObject("totalBill", totalBill);
        return modelAndView;
    }
    
    @RequestMapping("/vinay")
    public ModelAndView listDept3(HttpSession session,Authentication authentication) {
        List<Product> productList = productService.getAllProduct();
        int userId = (int) session.getAttribute("userId");
        ModelAndView modelAndView = new ModelAndView();
		Set<String> roles = AuthorityUtils.authorityListToSet(authentication.getAuthorities());

        for (Product product : productList) {
            boolean isAddedToCart = orderService.checkIfAddedToCart(product.getId(), userId);
            product.setAddedToCart(isAddedToCart);

        }

        modelAndView.setViewName("productdetails"); 
        modelAndView.addObject("product", productList);
        return modelAndView;
    }

    @RequestMapping("/vineetha")  
   	public ModelAndView listDept4(){  
   		List<UserDtls> userList=userService.getAllUser();
   		 		
   		ModelAndView modelAndView = new ModelAndView(); 
   		 
   		modelAndView.setViewName("userdetails");      
   		modelAndView.addObject("user", userList);    
   		return modelAndView;  
   	}
	    @RequestMapping(value="/cartdetails", method=RequestMethod.GET)  
		public ModelAndView cartDetails(HttpSession session){  
	    	int id = (int)session.getAttribute("userId");
			List<Orders> orderList=orderService.getOrdersByUserId(id);
			 
			 		
			ModelAndView modelAndView = new ModelAndView(); 
			 
			modelAndView.setViewName("cart");      
			modelAndView.addObject("orders", orderList);    
			return modelAndView;  
		}
	    @RequestMapping(value="/processPayment", method=RequestMethod.POST)
	    public ModelAndView processPayment(@ModelAttribute PaymentDetails paymentDetails, HttpSession session,@RequestParam("quantities") String quantities) {
	        int userId = (int) session.getAttribute("userId");
	        paymentDetails.setUserid(userId);
 
	        boolean isUTRExists = paymentService.isUTRExists(paymentDetails.getUtr());

	        ModelAndView modelAndView = new ModelAndView();

	        if (isUTRExists) {
	            
	            modelAndView.addObject("message", "An order has already been placed with this UTR.");
	        } else {
	   
	        	paymentDetails.setTime(LocalDateTime.now());
	        	paymentDetails.setStatus("Pending");
	            paymentService.save(paymentDetails);
	            List<Orders> orderList=orderService.getOrdersByUserId(userId);
	            String[] quantityArray = quantities.split(",");
	            for (int i = 0; i < orderList.size(); i++) {
	                Orders orders = orderList.get(i);
	                int quantity = Integer.parseInt(quantityArray[i].trim());

	                OrdersList ordersList = new OrdersList(paymentDetails.getId(), orders.getProductname(), orders.getProductprice(), quantity);
	                ordersListService.save(ordersList);
	            }
	        }

	        modelAndView.setViewName("paymentsuccess");
	        return modelAndView;
	    }
	    
	     
	   

		@RequestMapping("/jyothi")  
	   	public ModelAndView listDept5(HttpSession session){ 
	    	int userId = (int)session.getAttribute("userId");
	    	 List<PaymentDetails> paymentDetailsList=paymentService.getByUserid(userId);
	   		 		
	   		ModelAndView modelAndView = new ModelAndView(); 
	   		
	   		modelAndView.setViewName("orderlist");      
	   		   modelAndView.addObject("paymentDetails", paymentDetailsList);
	   		return modelAndView;  
	   	}
		@RequestMapping("/jyothi1")  
	   	public ModelAndView listDept6(HttpSession session){ 
	    	 
	    	 List<PaymentDetails> paymentDetailsList=paymentService.getAll();
	   		 		
	   		ModelAndView modelAndView = new ModelAndView(); 
	   		
	   		modelAndView.setViewName("orderlist1");      
	   		   modelAndView.addObject("paymentDetails", paymentDetailsList);
	   		return modelAndView;  
	   	}
	   
	    
	   
	    @RequestMapping(value="/openproduct", method=RequestMethod.GET)
	    public ModelAndView openproduct(@RequestParam("id") int id) {
	    	Product product = productService.getById(id);
	    	ModelAndView modelAndView = new ModelAndView();
	    	modelAndView.setViewName("openproduct");
	    	modelAndView.addObject("product", product);
	    	return modelAndView;
	    	
	    }
	    @RequestMapping(value="/addtoCart", method=RequestMethod.GET)
	    public ModelAndView addtoCart(@RequestParam("id") int id,HttpSession session) {
	    	 Product product = productService.getById(id);
	         String name = product.getProductname();
	         String price = product.getProductprice();
	         int productId = product.getId();
	         int userId = (int) session.getAttribute("userId");

	         Orders order = orderService.addOrder(productId, name, price, userId);
	         if (order != null) {
	             product.setAddedToCart(true);
	         }

	         List<Product> productList = productService.getAllProduct();
	         for (Product product1: productList) {
			        boolean isAddedToCart = orderService.checkIfAddedToCart(product1.getId(), userId);
			        if(isAddedToCart==true) {
		product1.setAddedToCart(true);
			        }
			        else {
			        	product1.setAddedToCart(false);
			        }
			    }
	         ModelAndView modelAndView = new ModelAndView();
	         modelAndView.setViewName("productdetails");
	         modelAndView.addObject("product", productList);
	         return modelAndView;
	    	
	    }
	    @RequestMapping(value="/addtoCart1", method=RequestMethod.POST)
	    public ModelAndView addtoCart1(@RequestParam("id") int id,HttpSession session) {
	    	 Product product = productService.getById(id);
	         String name = product.getProductname();
	         String price = product.getProductprice();
	         int productId = product.getId();
	         String message="Added Successfully!";
	         int userId = (int) session.getAttribute("userId");	         
	         Orders order = orderService.addOrder(productId, name, price, userId);	        
	         ModelAndView modelAndView = cartDetails(session);
	         modelAndView.addObject("message",message);        
	         return modelAndView;
	    	
	    }
	   
	    @RequestMapping(value="/openstaff", method=RequestMethod.GET)
	    public ModelAndView openstaff(@RequestParam("id") int id) {
	    	Staff staff = staffService.getById(id);
	    	ModelAndView modelAndView = new ModelAndView();
	    	modelAndView.setViewName("openstaff");
	    	modelAndView.addObject("staff", staff);
	    	return modelAndView;
	    	
	    }
	    @RequestMapping(value="/openuser", method=RequestMethod.GET)
	    public ModelAndView openuser(@RequestParam("id") int id) {
	    	UserDtls user = userService.getById(id);
	    	ModelAndView modelAndView = new ModelAndView();
	    	modelAndView.setViewName("openuser");
	    	modelAndView.addObject("user", user);
	    	return modelAndView;
	    	
	    }
	    
	        
	    @PostMapping(value = "/saveproduct")
	    public ModelAndView saveProduct(@ModelAttribute Product product, @RequestParam("image") MultipartFile file,@RequestParam("description") String description ) throws IOException, SerialException, SQLException {
	        // Save the product
	        productService.saveOrUpdate(product);

	        // Save the image
	        byte[] bytes = file.getBytes();
	        Blob blob = new javax.sql.rowset.serial.SerialBlob(bytes);
	        FruitImage fruit = new FruitImage();
	        fruit.setImage(blob);
	        fruit.setProductname(product.getProductname());
	        fruit.setProductprice(product.getProductprice());
	        fruit.setDescription(description);
	        
	        fruitImageService.saveOrUpdate(fruit);

	        ModelAndView modelAndView = new ModelAndView();
	        List<Product> productList = productService.getAllProduct();
	        modelAndView.setViewName("productdetails");
	        modelAndView.addObject("AddSuccess", true);
	        modelAndView.addObject("product", productList);
	        return modelAndView;
	    }
	    @PostMapping(value="/savestaff")  
	   	public ModelAndView savestaff(@ModelAttribute Staff staff, @RequestParam("image") MultipartFile file,@RequestParam("description") String description) throws IOException, SerialException, SQLException{  
	   		staffService.saveOrUpdate(staff);
	   		
	   	 byte[] bytes = file.getBytes();
	        Blob blob = new javax.sql.rowset.serial.SerialBlob(bytes);
	        StaffImage staff1 = new StaffImage();
	        staff1.setImage(blob);
	        staff1.setStaffname(staff.getName());
	        staff1.setDescription(description);
	        staff1.setQualification(staff.getQualification());
	         
	        staffImageService.saveOrUpdate(staff1);
	   		
	   		ModelAndView modelAndView = new ModelAndView(); 
	   		List<Staff> staffList=staffService.getAllStaff();		 
	   		modelAndView.setViewName("staffdetails");
	   		modelAndView.addObject("AddSuccess", true);
	   		modelAndView.addObject("staff", staffList);    
	   		return modelAndView;  
	   	}
	    
	    @RequestMapping(value="/saveuser", method=RequestMethod.POST)  
	   	public ModelAndView saveUser(@ModelAttribute UserDtls user){  
	   		userService.saveOrUpdate(user);
	   		ModelAndView modelAndView = new ModelAndView(); 
	   		List<UserDtls> userList=userService.getAllUser();		 
	   		modelAndView.setViewName("userdetails");
	   		modelAndView.addObject("user", userList); 
	   		modelAndView.addObject("editSuccess", true);
	   		return modelAndView;  
	   	}
	   
	    
	   
	     

	    
	    @RequestMapping(value="/updatestaff", method=RequestMethod.POST)  
	   	public ModelAndView updatestaff(@ModelAttribute Staff staff){  
	   		staffService.saveOrUpdate(staff);
	   		ModelAndView modelAndView = new ModelAndView(); 
	   		List<Staff> staffList=staffService.getAllStaff();		 
	   		modelAndView.setViewName("staffdetails");	
	   		modelAndView.addObject("editSuccess", true); 
	   		modelAndView.addObject("staff", staffList);    
	   		return modelAndView;  
	   	}
	    @RequestMapping(value="/updateproduct", method=RequestMethod.POST)  
		public ModelAndView updateProduct(@ModelAttribute Product product){  
			productService.saveOrUpdate(product);
			ModelAndView modelAndView = new ModelAndView(); 
			List<Product> productList=productService.getAllProduct();		 
			modelAndView.setViewName("productdetails");
			modelAndView.addObject("editSuccess", true);
			modelAndView.addObject("product", productList);    
			return modelAndView;  
		}    
	    
	    
	    @GetMapping("/display")

        public ResponseEntity<byte[]> displayImage(@RequestParam("id") int id) throws IOException, SQLException

        {

            FruitImage image = fruitImageService.getById(id);

            byte [] imageBytes = null;

            imageBytes = image.getImage().getBytes(1,(int) image.getImage().length());

            return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(imageBytes);

        }
        @GetMapping("/display1")

        public ResponseEntity<byte[]> display1Image(@RequestParam("id") int id) throws IOException, SQLException

        {

            StaffImage image = staffImageService.getById(id);

            byte [] imageBytes = null;

            imageBytes = image.getImage().getBytes(1,(int) image.getImage().length());

            return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(imageBytes);

        }
        @GetMapping("/display2")

        public ResponseEntity<byte[]> display2Image(@RequestParam("id") int id) throws IOException, SQLException

        {

            UserImage image = userImageService.getById(id);

            byte [] imageBytes = null;

            imageBytes = image.getImage().getBytes(1,(int) image.getImage().length());

            return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(imageBytes);

        }

 

        @GetMapping("/list")

        public ModelAndView fruitlList(){

            ModelAndView mv = new ModelAndView("list");

            List<FruitImage> hotelList = fruitImageService.getAllHotel();

            mv.addObject("hotel", hotelList);

            return mv;

        }
        
        @GetMapping("/stafflist")

        public ModelAndView staffList(){

            ModelAndView mv = new ModelAndView("stafflist");

            List<StaffImage> staffList = staffImageService.getAllStaff();

            mv.addObject("staff", staffList);

            return mv;

        }
        @GetMapping("/userlist")

        public ModelAndView userList(){

            ModelAndView mv = new ModelAndView("userlist");

            List<UserImage> userList = userImageService.getAllUser();

            mv.addObject("user", userList);

            return mv;

        }
        
        
        
        @RequestMapping(value = "/deletefromCart", method = RequestMethod.GET)
	    public ModelAndView deletefromCart(@RequestParam("id") int id,HttpSession session) {
	        orderService.delete(id);
	        ModelAndView modelAndView = cartDetails(session);
	        modelAndView.addObject("deleteSuccess", true);
	          
	        
	        return modelAndView;
	    }
	   
	    @RequestMapping(value="/deleteproduct", method=RequestMethod.GET)  
		public ModelAndView deleteproduct(@RequestParam("id") int id,HttpSession session,Authentication authentication){  
		    productService.delete(id);
		    fruitImageService.delete(id);
		    ModelAndView modelAndView = listDept3(session, authentication);
		     modelAndView.addObject("deleteSuccess", true);
		     return modelAndView;  
		}
	    @RequestMapping(value="/deletestaff", method=RequestMethod.GET)  
	   	public ModelAndView deletestaff(@RequestParam("id") int id){  
	   	   staffService.delete(id);
	   	   staffImageService.delete(id);
	   	 ModelAndView modelAndView = listDept2();
	     modelAndView.addObject("deleteSuccess", true);
	     return modelAndView; 
	   	}
	    @RequestMapping(value="/deleteuser", method=RequestMethod.GET)  
	   	public ModelAndView deleteuser(@RequestParam("id") int id){  
	   	   userService.delete(id);
	   	   userImageService.delete(id);
	   	    return listDept4();  
	   	}
	     
      
	

       }
