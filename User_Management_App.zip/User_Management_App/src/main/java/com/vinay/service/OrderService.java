package com.vinay.service;

import java.util.List;
import java.util.Optional;

//OrderService.java

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.vinay.model.Orders;
import com.vinay.repository.OrderRepository;

@Service
@Component
public class OrderService {
 private final OrderRepository orderRepository;

 @Autowired
 public OrderService(OrderRepository orderRepository) {
     this.orderRepository = orderRepository;
 }

 public Orders addOrder(int idq,String productName,String productPrice, int userId) {
	 Optional<Orders> existingOrder = orderRepository.findByProductidAndUserid(idq, userId);	    
	    if (existingOrder.isPresent()) {
	        return null;
	    } else {
	        
	        Orders order = new Orders();
	        order.setProductid(idq);
	        order.setProductprice(productPrice);
	        order.setProductname(productName);
	        order.setUserId(userId);
	        return orderRepository.save(order);
	    }
 }
 public boolean checkIfAddedToCart (int id,int userid) {
	 Optional<Orders> existingOrder = orderRepository.findByProductidAndUserid(id, userid);
	 if(existingOrder.isPresent()) {
		 return true;
	 }
	 else
		 return false;

 }
 public List<Orders> getOrdersByUserId(int userId) {
	    return orderRepository.findByUserid(userId);
	}
 public void delete(int id) {
		orderRepository.deleteById(id);
	}


}