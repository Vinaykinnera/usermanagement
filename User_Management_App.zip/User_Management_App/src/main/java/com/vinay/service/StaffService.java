package com.vinay.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vinay.model.Staff;
import com.vinay.repository.StaffRepository;
@Service
public class StaffService {
	@Autowired
	StaffRepository staffRepository;
	
	public Staff getById(int id) {
		Optional<Staff> staff = staffRepository.findById(id);
		return staff.get();
	}
	
	public void saveOrUpdate(Staff staff) {
		staffRepository.save(staff);
	}

	public List<Staff> getAllStaff() 
	{
		List<Staff> staff = new ArrayList<Staff>();
		staffRepository.findAll().forEach(x -> staff.add(x));
		return staff;
	}
	public void update(Staff staff, int id) 
	{
		staffRepository.save(staff);
	}

	public void delete(int id) {
		staffRepository.deleteById(id);
	}
}
