package com.vinay.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vinay.model.Product;
import com.vinay.repository.ProductRepository;
@Service
public class ProductService {
	@Autowired
	ProductRepository productRepository;
	
	public Product getById(int id) {
		Optional<Product> product = productRepository.findById(id);
		return product.get();
	}
	
	public void saveOrUpdate(Product product) {
		productRepository.save(product);
	}

	public List<Product> getAllProduct() 
	{
		List<Product> product = new ArrayList<Product>();
		productRepository.findAll().forEach(x -> product.add(x));
		return product;
	}
	public void update(Product product, int id) 
	{
		productRepository.save(product);
	}

	public void delete(int id) {
		productRepository.deleteById(id);
	}

	    
}

