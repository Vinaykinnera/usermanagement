package com.vinay.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

//OrderService.java

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.vinay.model.Orders;
import com.vinay.model.OrdersList;
import com.vinay.model.Product;
import com.vinay.model.Staff;
import com.vinay.repository.OrderRepository;
import com.vinay.repository.OrdersListRepository;

@Service
@Component
public class OrdersListService {
 private final OrdersListRepository ordersListRepository;

 @Autowired
 public OrdersListService(OrdersListRepository ordersListRepository) {
     this.ordersListRepository = ordersListRepository;
 }

 public void save(OrdersList ordersList) {
		ordersListRepository.save(ordersList);
	}
 public List<OrdersList> getAllOrders() 
	{
		List<OrdersList> ordersList = new ArrayList<OrdersList>();
		ordersListRepository.findAll().forEach(x -> ordersList.add(x));
		return ordersList;
	}
 public List<OrdersList> getById(long paymentId) {
		List<OrdersList> ordersList = ordersListRepository.findByPaymentid(paymentId);
		return ordersList;
	}


}