package com.vinay.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vinay.model.FruitImage;
import com.vinay.repository.FruitImageRepository;

@Service
public class FruitImageService {
	@Autowired
	FruitImageRepository fruitImageRepository;
	
	public FruitImage getById(int id) {
		Optional<FruitImage> hotel = fruitImageRepository.findById(id);
		return hotel.get();
	}
	
	public void saveOrUpdate(FruitImage fruitImage) {
		fruitImageRepository.save(fruitImage);
	}
	
	public List<FruitImage> getAllHotel() 
	{
		 return (List<FruitImage>) fruitImageRepository.findAll();
	}
	
	public void update(FruitImage fruitImage, int id) 
	{
		fruitImageRepository.save(fruitImage);
	}
	
	public void delete(int id) {
		fruitImageRepository.deleteById(id);
	}

}

