package com.vinay.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vinay.model.FruitImage;
import com.vinay.model.UserImage;
import com.vinay.repository.FruitImageRepository;
import com.vinay.repository.UserImageRepository;

@Service
public class UserImageService {
	@Autowired
	UserImageRepository userImageRepository;
	
	public UserImage getById(int id) {
		Optional<UserImage> hotel = userImageRepository.findById(id);
		return hotel.get();
	}
	
	public void saveOrUpdate(UserImage userImage) {
		userImageRepository.save(userImage);
	}
	
	public List<UserImage> getAllUser() 
	{
		 return (List<UserImage>)userImageRepository.findAll();
	}
	
	public void update(UserImage userImage, int id) 
	{
		userImageRepository.save(userImage);
	}
	
	public void delete(int id) {
		userImageRepository.deleteById(id);
	}

}

