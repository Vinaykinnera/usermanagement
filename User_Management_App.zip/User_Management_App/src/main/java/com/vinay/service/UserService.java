package com.vinay.service;

import java.util.List;


import com.vinay.model.UserDtls;

public interface UserService {

	public UserDtls createUser(UserDtls user);

	public boolean checkEmail(String email);

	public List<UserDtls> getAllUser();
	public void delete(int id);

	public void saveOrUpdate(UserDtls user);

	public UserDtls getById(int id);

}
