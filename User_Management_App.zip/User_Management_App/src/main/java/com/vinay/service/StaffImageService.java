package com.vinay.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vinay.model.FruitImage;
import com.vinay.model.StaffImage;
import com.vinay.repository.FruitImageRepository;
import com.vinay.repository.StaffImageRepository;

@Service
public class StaffImageService {
	@Autowired
	StaffImageRepository staffImageRepository;
	
	public StaffImage getById(int id) {
		Optional<StaffImage> hotel = staffImageRepository.findById(id);
		return hotel.get();
	}
	
	public void saveOrUpdate(StaffImage staffImage) {
		staffImageRepository.save(staffImage);
	}
	
	public List<StaffImage> getAllStaff() 
	{
		 return (List<StaffImage>) staffImageRepository.findAll();
	}
	
	public void update(StaffImage staffImage, int id) 
	{
		staffImageRepository.save(staffImage);
	}
	
	public void delete(int id) {
		staffImageRepository.deleteById(id);
	}

}

