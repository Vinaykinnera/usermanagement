package com.vinay.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.vinay.model.PaymentDetails;
import com.vinay.model.Product;
import com.vinay.model.Staff;
import com.vinay.repository.PaymentRepository;

@Service
public class PaymentService {
    private PaymentRepository paymentRepository;

    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    public void save(PaymentDetails paymentDetails) {
        // Perform any business logic/validation if required
   
        paymentRepository.save(paymentDetails);
        // Additional operations as needed
    }

	public boolean isUTRExists(String utr) {
		boolean vin = paymentRepository.existsByUtr(utr);
		if(vin==true) {
			return true;
		}
		else {
			return false;
		}
	}

	public List<PaymentDetails> getByUserid(int id) {
		List<PaymentDetails> paymentDetails = paymentRepository.findByUserid(id);
		return paymentDetails;
	}

	 

	public List<PaymentDetails> getAll() 
	{
		List<PaymentDetails> paymentDetails = new ArrayList<PaymentDetails>();
		paymentRepository.findAll().forEach(x -> paymentDetails.add(x));
		return paymentDetails;
	}
	
	public Optional<PaymentDetails> getById(long id){
		Optional<PaymentDetails>paymentDetails = paymentRepository.getById(id);
		return paymentDetails;
	}
 

	 
}
